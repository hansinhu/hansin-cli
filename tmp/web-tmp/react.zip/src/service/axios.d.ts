import { AxiosStatic } from 'axios'

declare const Axios: AxiosStatic

export default Axios
