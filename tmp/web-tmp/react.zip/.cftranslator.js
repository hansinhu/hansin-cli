module.exports = {
  project_id: "9ce1af5a-317a-48b5-b27c-7bb23333222a",
  client_id: "204cb72f-08e9-4c87-8cc2-b2def0b6f34a",
  client_secret: "p3pQLed970A8YZanJtQnM6tXXtJVT8PG",
  locales: ['en', 'ar', 'es', 'hi', 'id', 'it', 'pt'],
  format: "json",
  export_path: "/src/locales",
}
