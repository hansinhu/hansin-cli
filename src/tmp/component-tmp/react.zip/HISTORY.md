## 0.6.0

- support `maxColumnsPerRow`.

## 0.5.0

- support `theme="dark|light"`.

## 0.4.0

- support `columnLayout`.
- support `backgroundColor`.

## 0.3.0

- support `style` and `className` for footer column and footer item.
- support `LinkComponent` for footer item.

## 0.2.0

- Fix `lib` and `es` folders missing.

## 0.1.0

- First release.
